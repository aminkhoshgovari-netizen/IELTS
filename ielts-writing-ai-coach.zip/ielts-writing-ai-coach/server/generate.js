// On-demand generation: model answers, improved essay, comparison, learning-mode check,
// dictionary entry, daily question. Every input is validated; every output is validated.
import { askJson } from "./anthropic.js";
import { ApiError } from "./http.js";
import { prompts, MODEL_BANDS } from "./prompts.js";
import { S, LIMITS, parseAnalyzeInput, vModel, vImprove, vCompare, vCheck, vDefine, vDaily } from "./validate.js";

const bad = (m) => new ApiError("bad_request", 400, m);
const need = (v, name, max) => { const s = S(v); if (!s) throw bad(`${name} is required.`); if (s.length > max) throw bad(`${name} is too long (maximum ${max} characters).`); return s; };

export const ACTIONS = ["model", "improve", "compare", "check", "define", "daily"];

export async function runGenerate(action, b, { budgetMs = 55000 } = {}) {
  const deadline = Date.now() + budgetMs;
  switch (action) {
    case "model": {
      const band = Number(b.band);
      if (!MODEL_BANDS.includes(band)) throw bad("band must be one of 7, 7.5, 8, 8.5, 9.");
      const task = Number(b.task) === 1 ? 1 : 2;
      const i = { task, qtype: S(b.qtype).slice(0, 120) || "Mixed / Other", question: need(b.question, "question", LIMITS.question) };
      return askJson(prompts.model(i, band), vModel, deadline);
    }
    case "improve": {
      const i = parseAnalyzeInput(b, ApiError);
      return askJson(prompts.improve(i), vImprove, deadline);
    }
    case "compare": {
      const band = Number(b.band);
      if (!MODEL_BANDS.includes(band)) throw bad("band must be one of 7, 7.5, 8, 8.5, 9.");
      const i = { question: need(b.question, "question", LIMITS.question), essay: need(b.essay, "essay", LIMITS.essay) };
      return askJson(prompts.compare(i, need(b.model, "model", LIMITS.model), band), vCompare, deadline);
    }
    case "check": {
      return askJson(prompts.check(need(b.original, "original", 400), need(b.attempt, "attempt", 400), S(b.rule).slice(0, 120), S(b.explanation).slice(0, 300)), vCheck, deadline);
    }
    case "define": {
      const word = need(b.word, "word", LIMITS.word);
      return askJson(prompts.define(word), (r) => vDefine(r, word), deadline);
    }
    case "daily": {
      return askJson(prompts.daily(Number(b.task) === 1 ? 1 : 2), vDaily, deadline);
    }
    default:
      throw bad(`Unknown action. Use one of: ${ACTIONS.join(", ")}.`);
  }
}
